package com.hotspot.airhockey

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import javax.net.SocketFactory
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sqrt

const val PORT = 5050
const val W = 600f      // field width (logical)
const val H = 1000f     // field height (logical)
const val PR = 24f      // puck radius
const val MR = 44f      // mallet radius
const val GOAL = 220f   // goal width
const val WIN = 7       // score to win

/** Host runs the physics; guest only sends its mallet position. */
class Game(val host: Boolean) {
    @Volatile var px = W / 2
    @Volatile var py = H / 2
    @Volatile var hx = W / 2
    @Volatile var hy = H - 150f
    @Volatile var gx = W / 2
    @Volatile var gy = 150f
    @Volatile var sh = 0
    @Volatile var sg = 0
    private var vx = 0f
    private var vy = 0f
    private var freeze = 60
    private var phx = hx
    private var phy = hy
    private var pgx = gx
    private var pgy = gy
    val over: Boolean get() = sh >= WIN || sg >= WIN

    fun step() {
        if (freeze > 0) { freeze--; phx = hx; phy = hy; pgx = gx; pgy = gy; return }
        px += vx; py += vy
        vx *= 0.995f; vy *= 0.995f
        if (px < PR) { px = PR; vx = abs(vx) }
        if (px > W - PR) { px = W - PR; vx = -abs(vx) }
        val inGoal = px > (W - GOAL) / 2 && px < (W + GOAL) / 2
        if (py < PR && !inGoal) { py = PR; vy = abs(vy) }
        if (py > H - PR && !inGoal) { py = H - PR; vy = -abs(vy) }
        if (py < -PR) score(true) else if (py > H + PR) score(false)
        hit(hx, hy, hx - phx, hy - phy)
        hit(gx, gy, gx - pgx, gy - pgy)
        phx = hx; phy = hy; pgx = gx; pgy = gy
    }

    private fun score(byHost: Boolean) {
        if (byHost) sh++ else sg++
        px = W / 2; py = H / 2; vx = 0f; vy = 0f
        freeze = if (over) Int.MAX_VALUE else 60
    }

    private fun hit(mx: Float, my: Float, mvx0: Float, mvy0: Float) {
        var dx = px - mx
        var dy = py - my
        val d = sqrt(dx * dx + dy * dy)
        if (d >= MR + PR || d == 0f) return
        dx /= d; dy /= d
        px = mx + dx * (MR + PR)
        py = my + dy * (MR + PR)
        val m = sqrt(mvx0 * mvx0 + mvy0 * mvy0)
        val k = if (m > 40f) 40f / m else 1f
        val rel = (vx - mvx0 * k) * dx + (vy - mvy0 * k) * dy
        if (rel < 0) { vx -= 1.8f * rel * dx; vy -= 1.8f * rel * dy }
        val sp = sqrt(vx * vx + vy * vy)
        if (sp > 32f) { vx *= 32f / sp; vy *= 32f / sp }
    }
}

class GameView(c: Context, val g: Game, val onExit: () -> Unit) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var s = 1f
    private var ox = 0f
    private var oy = 0f

    override fun onDraw(c: Canvas) {
        s = min(width / W, height / H)
        ox = (width - W * s) / 2
        oy = (height - H * s) / 2
        c.drawColor(Color.rgb(10, 14, 30))
        c.save()
        if (!g.host) c.rotate(180f, width / 2f, height / 2f)  // guest sees own side at bottom
        c.translate(ox, oy)
        c.scale(s, s)
        p.style = Paint.Style.FILL
        p.color = Color.rgb(18, 48, 96)
        c.drawRect(0f, 0f, W, H, p)
        p.color = Color.rgb(255, 196, 0)
        c.drawRect((W - GOAL) / 2, 0f, (W + GOAL) / 2, 12f, p)
        c.drawRect((W - GOAL) / 2, H - 12f, (W + GOAL) / 2, H, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 4f
        p.color = Color.argb(160, 255, 255, 255)
        c.drawLine(0f, H / 2, W, H / 2, p)
        c.drawCircle(W / 2, H / 2, 90f, p)
        p.style = Paint.Style.FILL
        p.color = Color.WHITE
        c.drawCircle(g.px, g.py, PR, p)
        p.color = Color.rgb(235, 64, 52)
        c.drawCircle(g.hx, g.hy, MR, p)
        p.color = Color.rgb(52, 140, 235)
        c.drawCircle(g.gx, g.gy, MR, p)
        c.restore()
        p.color = Color.WHITE
        p.textSize = 64f
        val me = if (g.host) g.sh else g.sg
        val op = if (g.host) g.sg else g.sh
        c.drawText("$me", 24f, height - 24f, p)
        c.drawText("$op", 24f, 80f, p)
        if (g.over) {
            p.textAlign = Paint.Align.CENTER
            c.drawText(if (me >= WIN) "TUM JEET GAYE!" else "HAAR GAYE", width / 2f, height / 2f, p)
            p.textSize = 36f
            c.drawText("exit ke liye tap karo", width / 2f, height / 2f + 56f, p)
            p.textAlign = Paint.Align.LEFT
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP && g.over) { onExit(); return true }
        var tx = e.x
        var ty = e.y
        if (!g.host) { tx = width - tx; ty = height - ty }
        val lx = ((tx - ox) / s).coerceIn(MR, W - MR)
        val ly = (ty - oy) / s
        if (g.host) { g.hx = lx; g.hy = ly.coerceIn(H / 2 + MR, H - MR) }
        else { g.gx = lx; g.gy = ly.coerceIn(MR, H / 2 - MR) }
        return true
    }
}

class MainActivity : Activity() {
    @Volatile private var gen = 0
    private var sock: Socket? = null
    private var server: ServerSocket? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        showMenu("")
    }

    override fun onDestroy() { closeAll(); super.onDestroy() }

    private fun closeAll() {
        gen++
        try { sock?.close() } catch (_: Exception) {}
        try { server?.close() } catch (_: Exception) {}
        sock = null; server = null
    }

    private fun showMenu(msg: String) {
        closeAll()
        fun tv(t: String, sz: Float) = TextView(this).apply {
            text = t; textSize = sz; setTextColor(Color.WHITE)
            gravity = Gravity.CENTER; setPadding(0, 16, 0, 16)
        }
        val l = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
            setBackgroundColor(Color.rgb(10, 14, 30))
            addView(tv("AIR HOCKEY", 34f))
            addView(tv("Hotspot Multiplayer", 16f))
            if (msg.isNotEmpty()) addView(tv(msg, 16f))
            addView(Button(context).apply { text = "HOST - mera hotspot ON hai"; setOnClickListener { host() } })
            addView(Button(context).apply { text = "JOIN - dost ke hotspot se"; setOnClickListener { join() } })
        }
        setContentView(l)
    }

    private fun info(t: String) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = 20f
        gravity = Gravity.CENTER; setPadding(48, 48, 48, 48)
        setBackgroundColor(Color.rgb(10, 14, 30))
    }

    private fun host() {
        val id = ++gen
        setContentView(info("Dost ka intezaar...\n\n1. Apna Hotspot ON rakho\n2. Dost us hotspot se Wi-Fi connect kare\n3. Dost JOIN dabaye"))
        Thread {
            try {
                val ss = ServerSocket().apply { reuseAddress = true; bind(InetSocketAddress(PORT)) }
                server = ss
                val s = ss.accept()
                s.tcpNoDelay = true
                sock = s
                play(Game(true), s, id)
            } catch (e: Exception) {
                if (id == gen) runOnUiThread { showMenu("Host error: ${e.message}") }
            }
        }.start()
    }

    private fun join() {
        val id = ++gen
        val gw = (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).dhcpInfo.gateway
        if (gw == 0) { showMenu("Pehle dost ke hotspot se Wi-Fi connect karo"); return }
        val ip = "${gw and 255}.${gw shr 8 and 255}.${gw shr 16 and 255}.${gw shr 24 and 255}"
        setContentView(info("Connecting to $ip ..."))
        Thread {
            try {
                val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                val wifi = cm.allNetworks.firstOrNull {
                    cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
                }
                val s = (wifi?.socketFactory ?: SocketFactory.getDefault()).createSocket()
                sock = s
                s.connect(InetSocketAddress(ip, PORT), 6000)
                s.tcpNoDelay = true
                play(Game(false), s, id)
            } catch (e: Exception) {
                if (id == gen) runOnUiThread { showMenu("Connect nahi hua. Host pehle HOST dabaye. (${e.message})") }
            }
        }.start()
    }

    private fun play(game: Game, s: Socket, id: Int) {
        runOnUiThread {
            val view = GameView(this, game) { showMenu("") }
            setContentView(view)
            Thread { reader(game, s, id, view) }.start()
            Thread { writer(game, s, id, view) }.start()
        }
    }

    private fun reader(g: Game, s: Socket, id: Int, v: View) {
        try {
            val i = DataInputStream(BufferedInputStream(s.getInputStream()))
            while (id == gen) {
                if (g.host) {
                    g.gx = i.readFloat().coerceIn(MR, W - MR)
                    g.gy = i.readFloat().coerceIn(MR, H / 2 - MR)
                } else {
                    g.px = i.readFloat(); g.py = i.readFloat()
                    g.hx = i.readFloat(); g.hy = i.readFloat()
                    g.sh = i.readInt(); g.sg = i.readInt()
                    v.postInvalidate()
                }
            }
        } catch (e: Exception) { lost(id) }
    }

    private fun writer(g: Game, s: Socket, id: Int, v: View) {
        try {
            val o = DataOutputStream(BufferedOutputStream(s.getOutputStream()))
            while (id == gen) {
                if (g.host) {
                    g.step()
                    o.writeFloat(g.px); o.writeFloat(g.py)
                    o.writeFloat(g.hx); o.writeFloat(g.hy)
                    o.writeInt(g.sh); o.writeInt(g.sg)
                } else {
                    o.writeFloat(g.gx); o.writeFloat(g.gy)
                }
                o.flush()
                v.postInvalidate()
                Thread.sleep(16)
            }
        } catch (e: Exception) { lost(id) }
    }

    private fun lost(id: Int) {
        if (id == gen) runOnUiThread { showMenu("Connection toot gaya") }
    }
}
